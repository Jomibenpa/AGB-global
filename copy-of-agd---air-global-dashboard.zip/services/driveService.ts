// CLIENT ID from Google Cloud Console
// NOTE: To make this work, create a project at https://console.cloud.google.com/
// Enable "Google Drive API"
// Create Credentials -> OAuth Client ID -> Web Application
// Add your URL (e.g., http://localhost:5173 or your public URL) to "Authorized Javascript Origins"
const CLIENT_ID = process.env.GOOGLE_CLIENT_ID || 'YOUR_CLIENT_ID_HERE'; 
const API_KEY = process.env.API_KEY || ''; // Optional for Drive, but good for Discovery

const DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/drive/v3/rest';
const SCOPES = 'https://www.googleapis.com/auth/drive.file';
const FILE_NAME = 'agd_database_v1_4.json';

let tokenClient: any;
let gapiInited = false;
let gisInited = false;

export const DriveService = {
  isAvailable: () => {
    return CLIENT_ID !== 'YOUR_CLIENT_ID_HERE';
  },

  init: async (onInitComplete: () => void) => {
    if (!DriveService.isAvailable()) {
        console.warn("Google Drive Client ID not set.");
        return;
    }

    const gapi = (window as any).gapi;
    const google = (window as any).google;

    if (!gapi || !google) return;

    // Load GAPI
    gapi.load('client', async () => {
      await gapi.client.init({
        apiKey: API_KEY,
        discoveryDocs: [DISCOVERY_DOC],
      });
      gapiInited = true;
      if (gisInited) onInitComplete();
    });

    // Load GIS
    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: CLIENT_ID,
      scope: SCOPES,
      callback: '', // defined later
    });
    gisInited = true;
    if (gapiInited) onInitComplete();
  },

  signIn: async (): Promise<string> => {
    return new Promise((resolve, reject) => {
      tokenClient.callback = async (resp: any) => {
        if (resp.error) {
          reject(resp);
        }
        resolve(resp.access_token);
      };

      // Request scope if not granted, or just token
      if ((window as any).gapi.client.getToken() === null) {
        tokenClient.requestAccessToken({ prompt: 'consent' });
      } else {
        tokenClient.requestAccessToken({prompt: ''});
      }
    });
  },

  // Find the AGD file in Drive
  findFile: async () => {
    const response = await (window as any).gapi.client.drive.files.list({
      q: `name = '${FILE_NAME}' and trashed = false`,
      fields: 'files(id, name)',
    });
    const files = response.result.files;
    if (files && files.length > 0) {
      return files[0].id;
    }
    return null;
  },

  // Create file if it doesn't exist
  createFile: async (data: any) => {
    const fileContent = JSON.stringify(data, null, 2);
    const file = new Blob([fileContent], { type: 'application/json' });
    const metadata = {
      name: FILE_NAME,
      mimeType: 'application/json',
    };

    const accessToken = (window as any).gapi.client.getToken().access_token;
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', file);

    const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
      method: 'POST',
      headers: new Headers({ 'Authorization': 'Bearer ' + accessToken }),
      body: form,
    });
    const val = await res.json();
    return val.id;
  },

  // Update existing file
  updateFile: async (fileId: string, data: any) => {
    const fileContent = JSON.stringify(data, null, 2);
    const file = new Blob([fileContent], { type: 'application/json' });
    
    const accessToken = (window as any).gapi.client.getToken().access_token;
    
    // We use fetch for multipart upload (updating content)
    const res = await fetch(`https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`, {
      method: 'PATCH',
      headers: new Headers({ 
        'Authorization': 'Bearer ' + accessToken,
        'Content-Type': 'application/json'
      }),
      body: fileContent,
    });
    return await res.json();
  },

  // Load content
  loadFile: async (fileId: string) => {
    const response = await (window as any).gapi.client.drive.files.get({
      fileId: fileId,
      alt: 'media',
    });
    return response.result; // This is the JSON object
  }
};
